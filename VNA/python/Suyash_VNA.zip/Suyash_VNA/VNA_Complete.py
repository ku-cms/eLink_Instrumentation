#!/usr/bin/env python3
from itertools import islice
import sys, re
from pylab import *
import numpy as np
import skrf as rf
#rf.stylely()

import pylab
import pandas as pd

from matplotlib import pyplot as plt
#import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
from matplotlib import style
import pickle as pl
from itertools import islice
import sys, re, os
import numpy as np
import statistics
import skrf as rf
#print(rf.__version__)
#print(.__version__)
#rf.stylely()

import pylab
import pandas as pd

from matplotlib import pyplot as plt
from matplotlib.ticker import AutoMinorLocator
from matplotlib import style
import pickle as pl



cable_length = '35'     #This is important change for every diferent length.

# For Now you have to have to set the cable length mannually.
#At the end it will not show you the plots because I have commented plt.show.
# You will find the s2p iles in Plots/Redo_VNA
# Impeandance Plots will be at Plot folder. You can find more about those plots from their name.
# You need to put the name of all the files






def name(input):
    match = re.match(r'TP_\w+_\d+', input)
    name = match.group()
    if '1p4' in name: name = name.replace('1p4', '1.4')
    return name

def create(f):
    return str("Plots/Redo_VNA/"+f)

with open("List_of_File.txt") as fl:
    for line in fl.readlines():
        List_of_Files = line.strip().split(" ")
    fl.close

def split(word):
    return [char for char in word]

y_plot_value=[]
def display_mean_impedance(ax, t1, t2, col):##https://www.tutorialfor.com/questions-285739.htm

    lines = ax.get_lines()

    # delete any other array correponding to a line drawn in ax but the last one. This is a
    # brute force way of resetting the line data to the data current line
    if len(lines)>1:
        del lines[:-1]

    # ressure that length of line is 1.
    #print('size of lines:', len(lines))

    # store the line arrays into list. Every line drawn on the ax is considered as data
    Y = [line.get_ydata() for line in lines]
    X = [line.get_xdata() for line in lines]

    # create a table, and since the list X and Y should have size=1, place the first
    # element (array) in pandas table columns t and Z
    df = pd.DataFrame()
    df['t'] = X[0]
    df['Z'] = Y[0]

    # get the mean value of Z for a given time difference
    Z_mean =  df.query('t >=@t1 & t<=@t2').agg({'Z': 'mean'})
    print('Mean impedance from', t1, 'ns and', t2, 'ns =', Z_mean.values, 'for', lines[0])
    # plot the average line
    x_coor = [t1, t2]
    y_coor = [Z_mean, Z_mean]
    y_plot_value.append(int(Z_mean.values))
    ax.plot(x_coor, y_coor, color=col, linewidth=1, label='', linestyle='--')

def set_axes(ax, title, ymin, ymax, xmin, xmax, nolim):
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax.grid(True, color='0.8', which='minor')
    ax.grid(True, color='0.4', which='major')
    ax.set_title(title) #Time domain
    if nolim==False:
        ax.set_xlim((xmin, xmax))
        ax.set_ylim((ymin, ymax))
    plt.tight_layout()

def name(x):
    return x.strip(".vna").replace("Plots/Redo_VNA/", "").strip("TP_")



from optparse import OptionParser
parser= OptionParser()

ff1= create(List_of_Files[0])
ff2= create(List_of_Files[1])
ff3= create(List_of_Files[2])
ff4= create(List_of_Files[3])
ff5= create(List_of_Files[4])

IDchecker = 0
Breaker = True
while Breaker == True:

    Breaker = True
    FILE = List_of_Files[IDchecker]
    print("Creating s2p files for ", FILE)

    parser.add_option('--basename', metavar='T', type='string', action='store',
                      default='Redo_VNA/'+FILE, #31, 15, 33 #calibration_test.vna
                      dest='basename',
                      help='input text file')

    parser.add_option('--directory', metavar='T', type='string', action='store',
                      default='Plots',
                      dest='directory',
                      help='directory to store plots')

    (options,args) = parser.parse_args()
    # ==========end: options =============
    basename = options.basename
    dir_in= options.directory
    if '_\d+' in basename:
        cable = name(basename)
    else: cable = basename
    #date  = ''

    #basename = 'TP_1m_23_ChD1.vna' #TP_1m_33_ChD1.vna calibration_test
    #cable = name(basename)

    infile = pd.read_csv(basename+'.txt', names=['pt','f','s11R','s11I','s12R','s12I','s13R','s13I','s14R','s14I'], delim_whitespace=True, skiprows=1)
    infile.dropna(how='all')

    pd.set_option("display.max_rows", 5)

    fileindex = 0
    prevF = 0
    for i, row in infile.iterrows():
        if row['pt'] == 'PARAMETER:':
            # new set of points
            try:
                if not f.closed:
                    f.close()
            except:
                pass
            filename = dir_in+'/'+basename+ '_' + str(fileindex)+'.s2p'
            fileindex += 1
            f = open(filename,'w')
            f.write('# GHZ	S	RI	R	50.0\n')

            try:
                #print (row['f'][1:-1], row['s11R'][1:-1], row['s11I'][1:-1], row['s12R'][1:-1] )
                f.write(f"!freq       Rel{row['f'][1:-1]}       Im{row['f'][1:-1]}      Rel{row['s11R'][1:-1]}       Im{row['s11R'][1:-1]}        Rel{row['s11I'][1:-1]}        Im{row['s11I'][1:-1]}         Rel{row['s12R'][1:-1]}      Im{row['s12R'][1:-1]}\n")
            except:
                if row['f'][1:-1] == 'SDD':
                     f.write(f"!freq\tRelS11\tImS11\n")
            prevF = 0
        try:
            if float(row['s11R']) == float(row['s11R']) and float(row['f'])>prevF:
                f.write(f"{float(row['f']):.3f}\t{float(row['s11R'])}\t{float(row['s11I'])}\t{float(row['s12R'])}\t{float(row['s12I'])}\t{float(row['s13R'])}\t{float(row['s13I'])}\t{float(row['s14R'])}\t{float(row['s14I'])}\n")
                prevF = float(row['f'])
        except:
            pass

    example = rf.Network(dir_in+'/'+basename+'_0.s2p', f_unit='ghz')

    # .s2p format consist of following columns
    # Stim  Real (S11)  Imag(S11)  Real(S21)  Imag(S21)  Real(S12)  Imag(S12)  Real(S22)  Imag(S22)

    # however our columns and rows in 4x4 matrix are swaped
    #print (example.s)

    # the map to read the correct values is going to be the one on right side

    # S11 S13          00  01            S11 S12
    #            ---->           ---->
    # S12 S14          10  11            S21 S22

    # do the following to read the right elements rather than the default in touchstone files.
    # S11 : s[:,0,0]
    # S12 : s[:,1,0]
    # S13 : s[:,0,1]
    # S14 : s[:,1,1]

    #https://teledynelecroy.com/doc/an-introduction-to-sparameters
    print("Plotting the data.\n")
    with style.context('seaborn-ticks'):
        #Time domain reflectometry, measurement vs simulation
        fig0 = plt.figure(figsize=(8,4))
        fig0.patch.set_facecolor('xkcd:black')
        plt.style.use('dark_background')
        ax0=plt.subplot(1,2,1)
        #major_ticks = np.arange(0, 6.5, 0.5)
        #minor_ticks = np.arange(0, 6.5, 0.1)
        ax0.xaxis.set_minor_locator(AutoMinorLocator(2))
        ax0.yaxis.set_minor_locator(AutoMinorLocator(2))
        ax0.grid(True, color='0.8', which='minor')
        ax0.grid(True, color='0.4', which='major')
        example_dc = example.extrapolate_to_dc(kind='linear')
        plt.title('Frequency')
        example_dc.s11.plot_s_db(label='S11')
        example_dc.s21.plot_s_db(label='S12')
        plt.ylim((-200.0, 100.0))
        plt.xlim((100000, 2500000000))
        ax1=plt.subplot(1,2,2)
        ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
        ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
        ax1.grid(True, color='0.8', which='minor')
        ax1.grid(True, color='0.4', which='major')
        plt.title('Time domain reflection step response (DC extrapolation)') #The time_step component of the z-matrix vs frequency
        example_dc.s11.plot_z_time_step(attribute='z_time_step', pad=2000, window='hamming', z0=50, label='TD11')
        example_dc.s21.plot_z_time_step(attribute='z_time_step',pad=2000, window='hamming', z0=50, label='TD12')
        plt.ylim((-500.0, 500.0))
        plt.xlim((0, 30))
        plt.tight_layout()
        fig0.savefig(dir_in+'/'+cable+'_freq_time_Z_rf.png')

        # Gating the Reflection of Interest
        s11_gated = example.s11.time_gate()#(center=0, span=.2)#autogate on the fly
        s11_gated.name='gated '
        fig1 = plt.figure(figsize=(8,4))
        plt.subplot(121)
        example.s11.plot_s_db()
        s11_gated.plot_s_db() #s11.time_gate()
        plt.title('Frequency Domain')
        plt.subplot(122)
        example.s11.plot_s_db_time()
        s11_gated.plot_s_db_time()
        plt.title('Time Domain')
        plt.xlim((-5, 5))
        plt.tight_layout()
        #plt.show()
        fig1.savefig(dir_in+'/'+cable+'_fref_time_rf.png')

        fig = plt.figure(figsize=(14,6))
        #ax0 = fig.add_subplot(1, 2, 2)
        #example.plot_s_smith(draw_labels=True,m=1, n=0)
        #example.plot_s_smith(draw_labels=True)
        #plt.xlabel('Real Part');
        #plt.ylabel('Imaginary Part');
        #plt.title('Smith Chart');
        #plt.axis([-1.1,2.1,-1.1,1.1])
        #plt.legend(loc=5)
        for i in range(6):
           ax = fig.add_subplot(2,3,i+1)
           if i==0 :
             plt.axis([-1.1,2.1,-1.1,1.1])
             example.plot_s_smith(draw_labels=True,m=0, n=0, label='S11')
             example.plot_s_smith(draw_labels=True,m=1, n=0, label='S12')
           elif i==1:
               example.plot_z_re(m=0,n=0,label='Z11')
               example.plot_z_re(m=1,n=0,label='Z12')
           elif i==2:
               example.plot_z_im(m=0,n=0,label='Z11')
               example.plot_z_im(m=1,n=0,label='Z12')
           elif i==3:
               example.plot_s_db(m=0, n=0, label='S11') # 10
               example.plot_s_db(m=1, n=0, label='S12')
           elif i==4:
               example.plot_s_db_time(m=0, n=0, label='S11') # employs windowing before plotting to enhance impluse resolution.
               example.plot_s_db_time(m=1, n=0, label='S12')
           elif i==5:
               example.plot_z_time_db(m=0, n=0, label='Z11')    #plot_z_re_time
               example.plot_z_time_db(m=1, n=0, label='Z12')

        #plt.show()

        fig.savefig(dir_in+'/'+cable+'_rf.png')

        #pl.dump(fig, open(dir_in+'/'+cable+'pickle', 'wb'))

        parser.remove_option('--basename')
        parser.remove_option('--directory')


        IDchecker +=1

        if IDchecker >(len(List_of_Files)-1):
            break

print("Plots can be now found in Plots/Redo_VNA\n")
#******************************************************************************************************************************************************************
#******************************************************************************************************************************************************************

#####################
parser = OptionParser()



#subfile = '0';comp='12';S_ij=''  #Set the Subfile and comp mannually.
comps = ['11','12','21']
subfiles = ['0','0','1']

IDchecker = 0
Breaker = True

print("List of Cables being analysed",List_of_Files,"\n")

while Breaker == True:
    Breaker = True
    comp = comps[IDchecker]
    subfile = subfiles[IDchecker]

    if comp == '11' and subfile == '0': S_ij = '11'
    elif comp == '12'and subfile == '0': S_ij = '21'
    elif comp == '21' and subfile == '1': S_ij = '11'

    i = int(split(S_ij)[0])
    j = int(split(S_ij)[1])
    #print('S_ij ----->', i, j)

    out_dir = 'Plots'
    sub_out_dir = 'Redo_VNA'

    #####################
    # *.s2p Files format
    # Each record contains 1 stimulus value and 4 S-parameters (total of 9 values)
    #Stim  Real (S11)  Imag(S11)  Real(S21)  Imag(S21)  Real(S12)  Imag(S12)  Real(S22)  Imag(S22)

    # ==== our file format for vna_0: ====
    #!freq  RelS11    ImS11    RelS12    ImS12    RelS13    ImS13    RelS14   ImS14

    # parameter in file => read from software

    # S11 S13          00  01            S11 S12
    #            ---->           ---->
    # S12 S14          10  11            S21 S22


    # ==== our file format for vna_1: ====
    #!freq  RelS21    ImS21    RelS22    ImS22    RelS23    ImS23    RelS24   ImS24

    # parameter in file => read from software

    # S21 S23          00  01            S11 S12
    #            ---->           ---->
    # S22 S24          10  11            S21 S22
    #######################
    x_labels=[]

    cable_ID = name(ff1)

    fullpath1 = ff1
    filename1 = str(fullpath1).split('.vna')[0].split('/')[-1:][0]

    x_labels.append(filename1)

    fullpath2 = ff2
    filename2 = str(fullpath2).split('.vna')[0].split('/')[-1:][0]
    x_labels.append(filename2)

    fullpath3 = ff3
    filename3 = str(fullpath3).split('.vna')[0].split('/')[-1:][0]
    x_labels.append(filename3)

    fullpath4 = ff4
    filename4 = str(fullpath4).split('.vna')[0].split('/')[-1:][0]
    x_labels.append(filename4)

    fullpath5 = ff5
    filename5 = str(fullpath5).split('.vna')[0].split('/')[-1:][0]
    x_labels.append(filename5)

    x_labels.append("Caliberation")
    print("\nParameter being analysed\n","S"+comp)

    if cable_length == '20':
        net1 = rf.Network(out_dir+'/'+sub_out_dir+'/TP_20cm_12_ChD3_ChCMD.vna_'+subfile+'.s2p', f_unit='ghz')#33
        net2 = rf.Network('Plots/TP_20cm_31_ChD1.vna_'+subfile+'.s2p', f_unit='ghz') #23
        net3 = rf.Network('Plots/TP_20cm_49_ChD1.vna_'+subfile+'.s2p', f_unit='ghz')
    elif cable_length == '35':
        net4 = rf.Network(ff1+'_'+subfile+'.s2p', f_unit='ghz')
        net5 = rf.Network(ff2+'_'+subfile+'.s2p', f_unit='ghz')
        net6 = rf.Network(ff3+'_'+subfile+'.s2p', f_unit='ghz')
        net8 = rf.Network(ff4+'_'+subfile+'.s2p', f_unit='ghz')
        net10 = rf.Network(ff5+'_'+subfile+'.s2p', f_unit='ghz')
        #net8 = rf.Network('Plots/TP_35cm_56_ChD1.vna_'+subfile+'.s2p', f_unit='ghz')
        #net10 = rf.Network('Plots/Redo_VNA/TP_35cm_60_ChD1_Redo.vna_'+subfile+'.s2p', f_unit='ghz')
    elif cable_length == '100':
        #net1 = rf.Network('Plots/Redo_VNA/TP_1m_53_ChD0_rwy.vna_'+subfile+'.s2p', f_unit='ghz')
        net1 = rf.Network(ff1+'_'+subfile+'.s2p', f_unit='ghz')
        net2 = rf.Network(ff2+'_'+subfile+'.s2p', f_unit='ghz')
        net3 = rf.Network(ff3+'_'+subfile+'.s2p', f_unit='ghz')
        #net3 = rf.Network('Plots/Redo_VNA/TP_1m_53_ChD1_redo.vna_'+subfile+'.s2p', f_unit='ghz') #55 34G_CHD1
        #net3 = rf.Network('Plots/TP_1m_32_ChD1.vna_'+subfile+'.s2p', f_unit='ghz')
    elif cable_length == '140':
        net1 = rf.network.Network(ff1+'_'+subfile+'.s2p', f_unit='ghz')
        net2 = rf.network.Network(ff2+'_'+subfile+'.s2p', f_unit='ghz')
        net3 = rf.network.Network(ff3+'_'+subfile+'.s2p', f_unit='ghz')
    elif cable_length == '200':
        print('Plots/Redo_VNA/TP_2m_72_ChD0.vna_'+subfile+'.s2p')
        net1 = rf.network.Network(ff1+'_'+subfile+'.s2p', f_unit='ghz')
        net2 = rf.network.Network(ff2+'_'+subfile+'.s2p', f_unit='ghz')
        net3 = rf.network.Network(ff3+'_'+subfile+'.s2p', f_unit='ghz')
    else:
        filename = out_dir+'/'+sub_out_dir+'/FPC_0p6m.vna_'+subfile+'.s2p'
        net1 = rf.network.Network(filename, f_unit='ghz')#straight_SMA.vna, FPC_0p6

    netref = rf.network.Network(out_dir+'/'+sub_out_dir+'/straight_SMA.vna_'+subfile+'.s2p', f_unit='ghz')

    with style.context('seaborn-darkgrid'):

        fig0 = plt.figure(figsize=(10,4))
        fig0.patch.set_facecolor('xkcd:black')
        plt.style.use('dark_background')
        ax0=plt.subplot(1,2,1)
        ax1=plt.subplot(1,2,2)

        ax0.xaxis.set_minor_locator(AutoMinorLocator(2))
        ax0.yaxis.set_minor_locator(AutoMinorLocator(2))
        ax0.grid(True, color='0.8', which='minor')
        ax0.grid(True, color='0.4', which='major')

        if cable_length == '20':

            ## ---Frequency Domain Plots---:
            net1_dc = net1[i,j].extrapolate_to_dc(kind='linear')
            net2_dc = net2[i,j].extrapolate_to_dc(kind='linear')
            net3_dc = net3[i,j].extrapolate_to_dc(kind='linear')
            netref_dc = netref[i,j].extrapolate_to_dc(kind='linear')

            net1_dc.plot_s_db(label='S'+comp+', TP_20cm_12 (32)', ax=ax0, color='b')
            net2_dc.plot_s_db(label='S'+comp+', TP_20cm_31 (36)', ax=ax0, color='r')
            net3_dc.plot_s_db(label='S'+comp+', TP_20cm_49 (34)', ax=ax0, color='c')
            netref_dc.plot_s_db(label='S'+comp+', Calibration', ax=ax0, color='g')
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -50.0, 50.0, 1)

            ## ---Time Domain Plots---:
            net1_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename1, ax=ax1, color='b')
            display_mean_impedance(ax1, 2.0, 4.0, 'b')

            net2_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename2, ax=ax1, color='r')
            display_mean_impedance(ax1, 2.0, 4.0, 'r')

            net3_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename3, ax=ax1, color='c')
            display_mean_impedance(ax1, 2.0, 4.0, 'c')

            netref_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', Calibration', ax=ax1, color='g')
            display_mean_impedance(ax1, 0.0, 30.0, 'g')

            set_axes(ax1, 'Time Domain', 0.0, 400.0, 0.0, 30.0, 0)

            #plt.show()

        elif cable_length == '35':
            net4_dc = net4[i,j].extrapolate_to_dc(kind='linear')
            net5_dc = net5[i,j].extrapolate_to_dc(kind='linear')
            net6_dc = net6[i,j].extrapolate_to_dc(kind='linear')
            net8_dc = net8[i,j].extrapolate_to_dc(kind='linear')
            net10_dc = net10[i,j].extrapolate_to_dc(kind='linear')
            netref_dc = netref[i,j].extrapolate_to_dc(kind='linear')

            net4_dc.plot_s_db(label='S'+comp+filename1, ax=ax0, color='b')
            net5_dc.plot_s_db(label='S'+comp+filename2, ax=ax0, color='r')
            net6_dc.plot_s_db(label='S'+comp+filename3, ax=ax0, color='g')
            net8_dc.plot_s_db(label='S'+comp+filename4, ax=ax0, color='w')
            net10_dc.plot_s_db(label='S'+comp+filename5, ax=ax0, color='m')

            netref_dc.plot_s_db(label='S'+comp+', Calibration', ax=ax0, color='c')
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -50.0, 50.0, 1)


            net4_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename1, ax=ax1, color='b')
            display_mean_impedance(ax1,2.0,5.0,'b')
            net5_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename2, ax=ax1, color='r')
            display_mean_impedance(ax1, 2.0, 5.0, 'r')
            net6_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename3, ax=ax1, color='g')
            display_mean_impedance(ax1, 2.0, 5.0, 'g')
            net8_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename4, ax=ax1, color='w')
            display_mean_impedance(ax1, 2.0, 5.0, 'w')
            net10_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename5, ax=ax1, color='m')
            display_mean_impedance(ax1, 2.0, 5.0, 'm')


            netref_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', Calibration', ax=ax1, color='c')
            display_mean_impedance(ax1, 2.0, 5.0, 'c')
            set_axes(ax1, 'Time Domain', 0.0, 400.0, 0.0, 30.0, 0)




        elif cable_length == '100':
            net1_dc   = net1[i,j].extrapolate_to_dc(kind='linear')
            net2_dc   = net2[i,j].extrapolate_to_dc(kind='linear')
            net3_dc   = net3[i,j].extrapolate_to_dc(kind='linear')
            netref_dc = netref[i,j].extrapolate_to_dc(kind='linear')
            net1_dc.plot_s_db(label='S'+comp+', TP_35cm_60_D0 (34)', ax=ax0, color='b')
            net2_dc.plot_s_db(label='S'+comp+', TP_35cm_60_D1 (34)', ax=ax0, color='r')
            net3_dc.plot_s_db(label='S'+comp+', TP_35cm_60ChCMD(34)', ax=ax0, color='g')
            netref_dc.plot_s_db(label='S'+comp+', Calibration', ax=ax0, color='c')
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -50.0, 50.0, 1)

            net1_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_35cm_60_ChD0 (34)', ax=ax1, color='b')
            display_mean_impedance(ax1, 1.0, 4.0, 'b')

            net2_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_35cm_60_D1 (34)', ax=ax1, color ='r')
            display_mean_impedance(ax1, 1.0, 4.0, 'r')

            net3_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_35cm_60_ChMD(34)', ax=ax1, color='g')
            display_mean_impedance(ax1, 1.0, 4.0, 'g')

            netref_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', Calibration', ax=ax1, color='c')
            display_mean_impedance(ax1, 1.0, 4.0, 'c')

            set_axes(ax1, 'Time Domain', 0.0, 250.0, 0.0, 30.0, 0)

        elif cable_length == '140':
            net1_dc = net1[i,j].extrapolate_to_dc(kind='linear')
            net2_dc = net2[i,j].extrapolate_to_dc(kind='linear')
            net3_dc = net3[i,j].extrapolate_to_dc(kind='linear')
            netref_dc = netref[i,j].extrapolate_to_dc(kind='linear')

            net1_dc.plot_s_db(label='S'+comp+', TP_1p4m_41_D0 (34)', ax=ax0)#s11
            net2_dc.plot_s_db(label='S'+comp+', TP_1p4m_41_D1 (34)', ax=ax0)
            net3_dc.plot_s_db(label='S'+comp+', TP_1p4m_41_CMD (34)', ax=ax0)
            netref_dc.plot_s_db(label='S'+comp+', Calibration', ax=ax0)  #s11
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -200.0, 100.0, 1)

            net1_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_1p4m_34_D0 (34)', ax=ax1)
            display_mean_impedance(ax1, 4.0,12.0 , 'b')
            net2_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_1p4m_34_D1 (34)', ax=ax1)
            display_mean_impedance(ax1, 4.0,12.0 , 'r')
            net3_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', TP_1p4m_34_CMD (34)', ax=ax1)
            display_mean_impedance(ax1, 4.0,12.0 , 'g')
            netref_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', Calibration', ax=ax1)
            display_mean_impedance(ax1, 4.0,12.0 , 'c')
            set_axes(ax1, 'Time Domain', 0.0, 300.0, 0.0, 35.0, 0)

        elif cable_length == '200':
            net1_dc = net1[i,j].extrapolate_to_dc(kind='linear')
            net2_dc = net2[i,j].extrapolate_to_dc(kind='linear')
            net3_dc = net3[i,j].extrapolate_to_dc(kind='linear')
            netref_dc = netref[i,j].extrapolate_to_dc(kind='linear')

            net1_dc.plot_s_db(label='S'+comp+filename1, ax=ax0, color='b')
            net2_dc.plot_s_db(label='S'+comp+filename2, ax=ax0, color='r')
            net3_dc.plot_s_db(label='S'+comp+filename3, ax=ax0, color='g')
            netref_dc.plot_s_db(label='S'+comp+', Calibration', ax=ax0, color='c')
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -50.0, 50.0, 1)

            net1_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename1, ax=ax1, color='b')
            display_mean_impedance(ax1, 5.0,18.0 , 'b')
            net2_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename2, ax=ax1, color='r')
            display_mean_impedance(ax1, 5.0,18.0 , 'r')
            net3_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+filename3, ax=ax1, color='g')
            display_mean_impedance(ax1, 5.0,18.0 , 'g')
            netref_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', Calibration', ax=ax1, color='c')
            display_mean_impedance(ax1, 5.0,18.0 , 'c')

            set_axes(ax1, 'Time Domain', 0.0, 500.0, 0.0, 35.0, 0)

        else:
            # Freq Domain
            net1_dc = net1[i,j].extrapolate_to_dc(kind='linear')
            net1_dc.plot_s_db(label='S'+comp+', FPC_0p6', ax=ax0, color='b')
            set_axes(ax0, 'Frequency Domain', 100000, 6000000000, -50.0, 50.0, 1)

            # Time Domain
            net1_dc.plot_z_time_step(pad=0, window='hamming', z0=50, label='TD'+comp+', FPC_0p6', ax=ax1, color='b')
            display_mean_impedance(ax1, 0.0, 4.0, 'b')

            set_axes(ax1, 'Time Domain', 0.0, 200.0, 0.0, 30.0, 0)

        fig0.savefig('Plots/TP_'+cable_ID+'cm_freq_time_Z_rf_'+"S"+comp+'.png')

        #plt.show()
        IDchecker+=1

        if IDchecker >2:
            break
print("Data analysed. Plots stored in Plots folder.")
